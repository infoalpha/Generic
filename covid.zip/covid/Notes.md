

DAO -- Package 




1) DriverManager
2) Connection
3) Statement
4) resultset



Programmatic  -- JAVA + ANNOTATION
Declarative --  Writing in xml configuration


Progra + Declarative



Declarative ;


1) Datasource --- Intial connection object  -- Establishes connection to DB 


2) JDBC Template  --- This object connects Statements (Queries)  with DB Connection


SQL -- How to do crud --- CREATE



1) UserService and UserServiceImpl  --- int register(User user);
2) UserDao and UserDaoImpl  --  int register(User user);
3) Create Under spring-beans.xml  src/main/resources

 <bean id="jdbcTemplate" class="org.springframework.jdbc.core.JdbcTemplate">
    <property name="dataSource" ref="datasource" />
  </bean>

  <bean id="datasource" class="org.springframework.jdbc.datasource.DriverManagerDataSource">
    <property name="driverClassName" value="com.mysql.jdbc.Driver" />
    <property name="url" value="jdbc:mysql://localhost:3306/covid?serverTimezone=UTC" />
    <property name="username" value="root" />
    <property name="password" value="****" />
  </bean>




1) Controller --- A  -- addUser       ---- Takes User Object from Client and passes to service layer
2) Service --  B --- registerUser  --- Takes User object and passes it to Dao Layer
3) Dao    ---  C --- InsertUser    --- Take USer java object and convert it into insert sql query 
                                       execute statement


