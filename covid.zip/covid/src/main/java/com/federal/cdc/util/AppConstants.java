package com.federal.cdc.util;

public class AppConstants{


	public static String PENDING = "PENDING";

}
